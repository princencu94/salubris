<!DOCTYPE HTML>
<html>
  <head>
    <title>Contact Us</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <link href="css/app.css" rel="stylesheet">
    <link href="css/home.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1">
  </head>
  <body>
    <header class="page-width">
        <nav class="navbar  navbar-expand-lg navbar-light">
            <div class="container-fluid">
                <a class="navbar-brand" href="/">
                    <img src="images/logo.png" alt="" width="150" height="50">
                  </a>
              <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
              </button>
              <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0 fs-6 text">
                  <li class="nav-item">
                    <a class="nav-link active text-color" aria-current="page" href="#">Salubris Gymnacity</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link text-color" href="#">Managed Healthcare</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="/contact">Contact Us</a>
                  </li>
                  
                </ul>
                <div class="d-flex">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0 fs-6 text text-color">
                        <li class="nav-item">
                            <a class="nav-link" href="#">Our class schedule</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="/blog">Blog</a>
                        </li>
                    </ul>
                    <span class="pt-2"><a class="btn-back py-2 px-3 rounded-md" href={{ route('register') }} role="button">Login</a></span>
                </div>
              </div>
            </div>
          </nav>
    </header>

        {{-- Page banner --}}
        <div class="back-color">
          <div class="max-w-7xl mx-auto py-16 px-4 sm:py-24 sm:px-6 lg:px-8 lg:flex lg:justify-between">
            <div class="max-w-xl">
              <h2 class="text-4xl font-extrabold text-white sm:text-5xl sm:tracking-tight lg:text-6xl">Videos</h2>
              <p class="mt-5 text-xl text-white">Feel free to get in touch with us</p>
            </div>
          </div>
        </div>

        {{ $videos }}

      <footer>
          <p  class="pt-5">Copyright © 2021 Salutem Wellness</p>
      </footer>
  </body>
</html>