<x-app-layout>
  <x-slot name="header">
      <h2 class="font-semibold text-xl text-gray-800 leading-tight">
          {{ __('Live Streams') }}
      </h2>
  </x-slot>

  <div class="py-12">
      <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
          <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
              <div class="p-6 bg-white border-b border-gray-200">

                <div class="mx-auto py-12 px-4 max-w-7xl sm:px-6 lg:px-8 lg:py-24">
                    <div class="space-y-4">
                      <ul role="list" class="space-y-12 sm:grid sm:grid-cols-2 sm:gap-x-6 sm:gap-y-12 sm:space-y-0 lg:grid-cols-3 lg:gap-x-8">
                        @foreach ( $response  as $res)
                        <li>
                          <div class="space-y-4">
                            <div class="aspect-w-3 aspect-h-2">
                              <img class="object-cover shadow-lg rounded-lg" src={{ $res['snippet']['thumbnails']['high']['url'] }} alt={{ $res['snippet']['title'] }}>
                            </div>
                
                            <div class="space-y-2">
                              <div class="text-lg leading-6 font-medium space-y-1">
                                <h3>{{ $res['snippet']['title'] }}</h3>
        
                              </div>
                            </div>
                          </div>
                        </li>
                        @endforeach
                        <!-- More people... -->
                      </ul>
                    </div>
                  </div>
                
              </div>
          </div>
      </div>
  </div>
</x-app-layout>

