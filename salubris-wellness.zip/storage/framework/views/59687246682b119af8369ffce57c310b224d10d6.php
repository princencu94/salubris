<!DOCTYPE HTML>
<html>
  <head>
    <title>Home Page</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <link href="css/app.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</head>
  <body>

        <header class="page-width">
            <nav class="navbar  navbar-expand-lg navbar-light">
                <div class="container-fluid">
                    <a class="navbar-brand" href="/">
                        <img src="images/logo.png" alt="" width="150" height="50">
                      </a>
                  <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                  </button>
                  <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0 fs-6 text">
                      <li class="nav-item">
                        <a class="nav-link active text-color" aria-current="page" href="#">Salubris Gymnacity</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link text-color" href="#">Managed Healthcare</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link" href="#">Rewards</a>
                      </li>
                      
                    </ul>
                    <div class="d-flex">
                        <ul class="navbar-nav me-auto mb-2 mb-lg-0 fs-6 text text-color">
                            <li class="nav-item">
                                <a class="nav-link" href="#">Our class schedule</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#">The Modern Parent</a>
                            </li>
                        </ul>
                      <button class="btn btn-outline-success" type="submit">Login</button>
                    </div>
                  </div>
                </div>
              </nav>
        </header>

      <div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="carousel">
        <div class="carousel-indicators">
          <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
          <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>
          <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2" aria-label="Slide 3"></button>
        </div>
        <div class="carousel-inner">
          <div class="carousel-item active">
            <img src="images/hero-wellness-1.jpg" class="d-block w-100" alt="...">
            <div class="carousel-caption d-none d-md-block">
              <h5>Your total wellbeing is our obligation</h5>

            </div>
          </div>
          <div class="carousel-item">
            <img src="images/hero-wellness-2.jpg" class="d-block w-100" alt="...">
            <div class="carousel-caption d-none d-md-block">
              <h5>Salubris- wellness with a difference</h5>
            </div>
          </div>
          <div class="carousel-item">
            <img src="images/hero-wellness-3.jpg" class="d-block w-100" alt="...">
            <div class="carousel-caption d-none d-md-block">
              <h5>We cater to your total wellness needs, mind and body</h5>
            </div>
          </div>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="visually-hidden">Next</span>
        </button>
      </div>

      <div id="intro-section" class="page-width">
        <div class="intro-image">
            <img src="images/intro.png" class="d-block w-100" alt="...">
        </div>
        <div class="intro-content">
            <h2 class="mb-3">All the variety you crave with 20 daily LIVE & 7,000+ on-demand classes</h2>
            <p class="pb-3">With 15 class types for every style, mood, and level—you’ll always look forward to your workout! Tune in LIVE, or fit an on-demand class into your schedule. Stream obé on any device or cast it big via Apple TV, Roku, Fire TV, or Chromecast.</p>
            <a class="btn-back py-2 px-5" href="#" role="button">Start Today</a>
          </div>
      </div>

      <div class="class-section-back">
        <div class="spacer"></div>
        <div id="class-section" class="page-width">
          <div class="class-content">
            <h2 class="mb-3 text-center">Effective programs that deliver results</h2>
            <p class="pb-3 text-center">Whether you’re just starting your fitness journey, exploring something new, or ready for a Hard AF challenge, get motivated with curated training programs that take you for a ride and amp up amazing results.</p>
            <a class="btn-back py-2 px-5" href="#" role="button">Start Today</a>
          </div>
          <div class="class-images">
            <div class="workout-card">
                <div class="workout-card-top">
                    <img src="images/trainers-1.jpg" class="d-block w-100" alt="...">
                </div>
                <div class="workout-card-content mt-3">
                  <h5>Body Comp</h5>
                </div>
            </div>

            <div class="workout-card">
              <div class="workout-card-top">
                  <img src="images/trainers-2.jpg" class="d-block w-100" alt="...">
              </div>
              <div class="workout-card-content mt-3">
                <h5>Starter Pack</h5>
              </div>
          </div>
            
          </div>
        </div>
        <div class="spacer"></div>
      </div>
      

      
      <div id="price-section-container">
        <div class="price-section-header mt-5">
            <h2>Start your free trial today!</h2>
            <p>No charge until the trial ends. Cancel anytime.</p>
        </div>
        <div id="price-section" class="mt-5 mb-5">
              <div class="price-card">
                  <div class="price-content">
                      <div class="card-top mb-3 border-bottom pb-3">
                          <h3 class="mb-4 fw-bold">Salubris Plata</h3>
                          <p class="mb-4">You can start your journey towards a healthy lifestyle</p>
                          <h3 class="mb-5"><span class="fw-bold fs-1">$0.50</span><span class="fs-5">/mo</span></h3>
                          <a class="mb-3" href="">Start Today</a>
                      </div>
                      <div class="card-bottom">
                          <h6 class="fw-bold">WHAT'S INCLUDED</h6>
                          <ul>
                              <li>Just some listings</li>
                              <li>Just some listings</li>
                          </ul>
                      </div>
                  </div>
              </div>

              <div class="price-card">
                  <div class="price-content">
                      <div class="card-top mb-3 border-bottom pb-3">
                          <h3 class="mb-4 fw-bold">Salubris Norm</h3>
                          <p class="mb-4">Get access to our Salubris Wellness product</p>
                          <h3 class="mb-5"><span class="fw-bold fs-1">$0.75</span><span class="fs-5">/mo</span></h3>
                          <a class="mb-3" href="">Start Today</a>
                      </div>
                      <div class="card-bottom">
                          <h6 class="fw-bold">WHAT'S INCLUDED</h6>
                          <ul>
                              <li>Just some listings</li>
                              <li>Just some listings</li>
                          </ul>
                      </div>
                  </div>
              </div>

              <div class="price-card">
                  <div class="price-content">
                      <div class="card-top mb-3 border-bottom pb-3">
                          <h3 class="mb-4 fw-bold">Salubris Prima</h3>
                          <p class="mb-4">Get unbelievable discounts and rewards by subscribing to our premium package</p>
                          <h3 class="mb-5"><span class="fw-bold fs-1">$1</span><span class="fs-5">/mo</span></h3>
                          <a class="mb-3" href="">Start Today</a>
                      </div>
                      <div class="card-bottom">
                          <h6 class="fw-bold">WHAT'S INCLUDED</h6>
                          <ul>
                              <li>Just some listings</li>
                              <li>Just some listings</li>
                          </ul>
                      </div>
                  </div>
              </div>
        </div>
      </div>

      <div class="partners-section-container ">
        <div class="price-section-header mt-5 pt-5">
          <h2>Our Partners</h2>
          <p>We have partnered with great stakeholders so that you can be fit</p>
        </div>
        <div class="partners-sections mt-5 pb-5">
          <div>
            <img src="images/partner-1.png" class="d-block w-100" alt="...">
          </div>
          <div>
            <img src="images/partner-2.png" class="d-block w-100" alt="...">
          </div>
          <div>
            <img src="images/partner-3.png" class="d-block w-100" alt="...">
          </div>
          <div>
            <img src="images/partner-4.png" class="d-block w-100" alt="...">
          </div>
          <div>
            <img src="images/partner-5.png" class="d-block w-100" alt="...">
          </div>
          <div>
            <img src="images/partner-6.png" class="d-block w-100" alt="...">
          </div>
          <div>
            <img src="images/partner-7.png" class="d-block w-100" alt="...">
          </div>
        </div>
      </div>

      <footer>
          <p  class="pt-5">Copyright © 2021 Salutem Wellness</p>
      </footer>
  </body>
</html><?php /**PATH C:\Users\MRKT\salubris\salubris-wellness\resources\views/home.blade.php ENDPATH**/ ?>