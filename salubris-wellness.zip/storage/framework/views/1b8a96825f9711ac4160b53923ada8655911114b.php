<!DOCTYPE HTML>
<html>
  <head>
    <title>Contact Us</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <link href="css/app.css" rel="stylesheet">
    <link href="css/home.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1">
  </head>
  <body>
    <header class="page-width">
        <nav class="navbar  navbar-expand-lg navbar-light">
            <div class="container-fluid">
                <a class="navbar-brand" href="/">
                    <img src="images/logo.png" alt="" width="150" height="50">
                  </a>
              <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
              </button>
              <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0 fs-6 text">
                  <li class="nav-item">
                    <a class="nav-link active text-color" aria-current="page" href="#">Salubris Gymnacity</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link text-color" href="#">Managed Healthcare</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="/contact">Contact Us</a>
                  </li>
                  
                </ul>
                <div class="d-flex">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0 fs-6 text text-color">
                        <li class="nav-item">
                            <a class="nav-link" href="#">Our class schedule</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="/blog">Blog</a>
                        </li>
                    </ul>
                    <span class="pt-2"><a class="btn-back py-2 px-3 rounded-md" href=<?php echo e(route('register')); ?> role="button">Login</a></span>
                </div>
              </div>
            </div>
          </nav>
    </header>

        
        <div class="back-color">
          <div class="max-w-7xl mx-auto py-16 px-4 sm:py-24 sm:px-6 lg:px-8 lg:flex lg:justify-between">
            <div class="max-w-xl">
              <h2 class="text-4xl font-extrabold text-white sm:text-5xl sm:tracking-tight lg:text-6xl">Contact Us</h2>
              <p class="mt-5 text-xl text-white">Feel free to get in touch with us</p>
            </div>
          </div>
        </div>

        <div class="relative bg-white">
            <div class="absolute inset-0">
              <div class="absolute inset-y-0 left-0 w-1/2 bg-gray-50"></div>
            </div>
            <div class="relative max-w-7xl mx-auto lg:grid lg:grid-cols-5">
              <div class="bg-gray-50 py-16 px-4 sm:px-6 lg:col-span-2 lg:px-8 lg:py-24 xl:pr-12">
                <div class="max-w-lg mx-auto">
                  <h2 class="text-2xl font-extrabold tracking-tight text-gray-900 sm:text-3xl">
                    Get in touch
                  </h2>
                  <p class="mt-3 text-lg leading-6 text-gray-500">
                    Nullam risus blandit ac aliquam justo ipsum. Quam mauris volutpat massa dictumst amet. Sapien tortor lacus arcu.
                  </p>
                  <dl class="mt-8 text-base text-gray-500">
                    <div>
                      <dt class="sr-only">Postal address</dt>
                      <dd>
                        <p>14 Argyle Road, Avondale</p>
                        <p>Harare</p>
                      </dd>
                    </div>
                    <div class="mt-6">
                      <dt class="sr-only">Phone number</dt>
                      <dd class="flex">
                        <!-- Heroicon name: outline/phone -->
                        <svg class="flex-shrink-0 h-6 w-6 text-gray-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
                          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                        </svg>
                        <span class="ml-3">
                          +263 (777) 8123 45
                        </span>
                      </dd>
                    </div>
                    <div class="mt-3">
                      <dt class="sr-only">Email</dt>
                      <dd class="flex">
                        <!-- Heroicon name: outline/mail -->
                        <svg class="flex-shrink-0 h-6 w-6 text-gray-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
                          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                        </svg>
                        <span class="ml-3">
                          support@salubriswellness.com
                        </span>
                      </dd>
                    </div>
                  </dl>
                </div>
              </div>
              <div class="bg-white py-16 px-4 sm:px-6 lg:col-span-3 lg:py-24 lg:px-8 xl:pl-12">
                <div class="max-w-lg mx-auto lg:max-w-none">
                  <form action="#" method="POST" class="grid grid-cols-1 gap-y-6">
                    <div>
                      <label for="full-name" class="sr-only">Full name</label>
                      <input type="text" name="full-name" id="full-name" autocomplete="name" class="block w-full shadow-sm py-3 px-4 placeholder-gray-500 focus:ring-indigo-500 focus:border-indigo-500 border-gray-300 rounded-md" placeholder="Full name">
                    </div>
                    <div>
                      <label for="email" class="sr-only">Email</label>
                      <input id="email" name="email" type="email" autocomplete="email" class="block w-full shadow-sm py-3 px-4 placeholder-gray-500 focus:ring-indigo-500 focus:border-indigo-500 border-gray-300 rounded-md" placeholder="Email">
                    </div>
                    <div>
                      <label for="phone" class="sr-only">Phone</label>
                      <input type="text" name="phone" id="phone" autocomplete="tel" class="block w-full shadow-sm py-3 px-4 placeholder-gray-500 focus:ring-indigo-500 focus:border-indigo-500 border-gray-300 rounded-md" placeholder="Phone">
                    </div>
                    <div>
                      <label for="message" class="sr-only">Message</label>
                      <textarea id="message" name="message" rows="4" class="block w-full shadow-sm py-3 px-4 placeholder-gray-500 focus:ring-indigo-500 focus:border-indigo-500 border border-gray-300 rounded-md" placeholder="Message"></textarea>
                    </div>
                    <div>
                      <button type="submit" class="inline-flex justify-center py-3 px-6 border border-transparent shadow-sm text-base font-medium rounded-md text-white back-color hover:text-black">
                        Submit
                      </button>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
      

      <footer>
          <p  class="pt-5">Copyright © 2021 Salutem Wellness</p>
      </footer>
  </body>
</html><?php /**PATH C:\Users\MRKT\salubris\salubris-wellness\resources\views/contact.blade.php ENDPATH**/ ?>